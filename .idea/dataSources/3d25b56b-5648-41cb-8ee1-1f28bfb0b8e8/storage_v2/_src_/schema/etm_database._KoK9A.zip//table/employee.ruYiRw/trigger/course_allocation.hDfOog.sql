create definer = root@localhost trigger course_allocation
    after update
    on employee
    for each row
BEGIN
	IF (new.dept_id != old.dept_id)
    THEN
    INSERT INTO takes (employee_id, course_id, number, state, time)
   SELECT employee.id as employee_id,
   		  necessity.course_id as course_id,
          null as number,
          null as state,
          null as time
   FROM employee JOIN necessity
   WHERE new.dept_id != old.dept_id
   AND employee.dept_id = necessity.dept_id;
	END IF;
END;

